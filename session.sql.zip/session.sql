-- phpMyAdmin SQL Dump
-- version 4.2.11
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Apr 02, 2016 at 04:50 PM
-- Server version: 5.6.21
-- PHP Version: 5.5.19

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `session`
--

-- --------------------------------------------------------

--
-- Table structure for table `exam`
--

CREATE TABLE IF NOT EXISTS `exam` (
`id` int(11) NOT NULL,
  `questions` varchar(1000) NOT NULL,
  `sub` varchar(12) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `exam`
--

INSERT INTO `exam` (`id`, `questions`, `sub`) VALUES
(1, 'dfds', 'html'),
(2, 'fdsf', 'html'),
(3, 'fdsf', 'html'),
(4, 'fdsf', 'html'),
(5, 'fdsf', 'html'),
(6, 'fdsf', 'html'),
(7, 'fdsf', 'html'),
(8, 'fdsf', 'html'),
(9, 'fdsf', 'html');

-- --------------------------------------------------------

--
-- Table structure for table `lesson`
--

CREATE TABLE IF NOT EXISTS `lesson` (
`id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `subtitle` varchar(250) NOT NULL,
  `paraph` longtext NOT NULL,
  `code` longtext NOT NULL,
  `sub` varchar(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `lesson`
--

INSERT INTO `lesson` (`id`, `title`, `subtitle`, `paraph`, `code`, `sub`) VALUES
(1, 'Lesson One', 'html basic', 'gkjrghjghsdngsjgj', '<!-- Modal -->\r\n<div id="myModal" class="modal fade" role="dialog">\r\n  <div class="modal-dialog">\r\n\r\n    <!-- Modal content-->\r\n    <div class="modal-content">\r\n      <div class="modal-header">\r\n        <button type="button" class="close" data-dismiss="modal">&times;</button>\r\n        <h4 class="modal-title">Modal Header</h4>\r\n      </div>\r\n      <div class="modal-body">\r\n        <p>Some text in the modal.</p>\r\n      </div>\r\n      <div class="modal-footer">\r\n        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>\r\n      </div>\r\n    </div>\r\n\r\n  </div>\r\n</div>', '1'),
(2, 'lessonn 2', 'php', 'what the hell', 'afjkh', 'html');

-- --------------------------------------------------------

--
-- Table structure for table `music`
--

CREATE TABLE IF NOT EXISTS `music` (
  `id` int(11) NOT NULL,
  `title` varchar(150) NOT NULL,
  `singer` varchar(100) NOT NULL,
  `lyricist` varchar(50) NOT NULL,
  `genre` varchar(25) NOT NULL,
  `file` text NOT NULL,
  `user_id` int(11) NOT NULL,
  `audio_type` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `music`
--

INSERT INTO `music` (`id`, `title`, `singer`, `lyricist`, `genre`, `file`, `user_id`, `audio_type`) VALUES
(2, 'fdgaaa', 'dfgdfgx', 'dfgx', 'fdgdfgx', 'post/audios/1440317927.mp3', 7, 'audio/mpeg');

-- --------------------------------------------------------

--
-- Table structure for table `photography`
--

CREATE TABLE IF NOT EXISTS `photography` (
  `id` int(11) NOT NULL,
  `title` varchar(150) NOT NULL,
  `photographer` varchar(50) NOT NULL,
  `genre` varchar(25) NOT NULL,
  `file` text NOT NULL,
  `user_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `photography`
--

INSERT INTO `photography` (`id`, `title`, `photographer`, `genre`, `file`, `user_id`) VALUES
(1, 'fgdfg@@@', 'dfg@', 'dfgdfg@@', 'post/images/1440307433.jpg', 6),
(2, 'sfds', 'sdfsd', 'fsdf', 'post/images/1440307528.JPG', 6);

-- --------------------------------------------------------

--
-- Table structure for table `short_films`
--

CREATE TABLE IF NOT EXISTS `short_films` (
  `id` int(11) NOT NULL,
  `title` varchar(150) NOT NULL,
  `director` varchar(255) NOT NULL,
  `actors` varchar(100) NOT NULL,
  `music_director` varchar(50) NOT NULL,
  `cinematography` varchar(50) NOT NULL,
  `genre` varchar(25) NOT NULL,
  `file` text NOT NULL,
  `video_type` varchar(20) NOT NULL,
  `user_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `short_films`
--

INSERT INTO `short_films` (`id`, `title`, `director`, `actors`, `music_director`, `cinematography`, `genre`, `file`, `video_type`, `user_id`) VALUES
(2, 'ds', 'sadsa', 'sad', 'ssad', 'sad', 'sdasd', 'post/videos/1440313934.mp4', 'video/mp4', 7),
(3, 'dsf', 'df', 'df', 'df', 'df', 'df', 'post/videos/1440314040.webm', 'video/webm', 7);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
`user_id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `firstname` varchar(255) NOT NULL,
  `lastname` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `type` tinyint(4) NOT NULL DEFAULT '0'
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `username`, `password`, `firstname`, `lastname`, `email`, `type`) VALUES
(1, 'admin', '202cb962ac59075b964b07152d234b70', 'prahveen', 'adrian', 'efwbf', 1),
(3, 'gava', '202cb962ac59075b964b07152d234b70', 'gava', 'gava', 'gava@gmail.cpm', 0),
(4, 'gowse92', '202cb962ac59075b964b07152d234b70', 'Gowsegan', 'Gowse', 'gowsegan92@hotmail.com', 0);

-- --------------------------------------------------------

--
-- Table structure for table `video`
--

CREATE TABLE IF NOT EXISTS `video` (
`id` int(11) NOT NULL,
  `title` varchar(200) NOT NULL,
  `subtitle` varchar(200) NOT NULL,
  `url` varchar(500) NOT NULL,
  `sub` varchar(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `video`
--

INSERT INTO `video` (`id`, `title`, `subtitle`, `url`, `sub`) VALUES
(1, 'testing', 'testing 2', 'cqszz_OfAFQ', 'html'),
(2, 'sdfsd', 'subtitle', 'dsfdsf', 'html'),
(3, 'dfdsa', 'subtitle', 'dsf', 'html');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `exam`
--
ALTER TABLE `exam`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `lesson`
--
ALTER TABLE `lesson`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
 ADD PRIMARY KEY (`user_id`);

--
-- Indexes for table `video`
--
ALTER TABLE `video`
 ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `exam`
--
ALTER TABLE `exam`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `lesson`
--
ALTER TABLE `lesson`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `video`
--
ALTER TABLE `video`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
